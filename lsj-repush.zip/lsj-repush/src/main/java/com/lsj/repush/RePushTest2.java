package com.lsj.repush;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import cn.hutool.json.JSONUtil;
import com.lsj.repush.utils.BatchHandleUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * @author lishangj
 */
@Slf4j
public class RePushTest2 {

    private static volatile String COOKIES = "";

    private static final String PRE_PATH = "/Users/saibo.yf/Documents/Corps/Cainiao - 4PX/履行融合/切分/";

    private static final String errRetry = PRE_PATH + "failedList.csv";

    static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(100, 100, 30, TimeUnit.MINUTES, new LinkedBlockingQueue<>());

    static FileWriter fw = null;


    public static void main(String[] args) {

        try {
            File f = new File(errRetry);
            if (f.exists()) {
                f.delete();
            }
            fw = new FileWriter(f);

            RePushTest2 rePushTest = new RePushTest2();

            // 创建 RestTemplate 实例
            RestTemplate restTemplate = new RestTemplate();

            // 设置连接参数
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

            requestFactory.setConnectTimeout(20000); // 设置连接超时时间为5秒

            requestFactory.setReadTimeout(500000); // 设置读取超时时间为5秒

            restTemplate.setRequestFactory(requestFactory);

            //for(int i=129; i<= 649; ){
            //
            //    //前开后闭
            //    rePushTest.doRepush(restTemplate,i,Math.min(649,i+10));
            //
            //    i+=10;
            //
            //}

            //前开后闭
            rePushTest.doRepush(restTemplate, 1, 20);

        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (fw != null) {
                try {
                    fw.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }




    private void doRepush(RestTemplate restTemplate, int startCount, int endCount) {
        CountDownLatch countDownLatch = new CountDownLatch(endCount-startCount+1);
        for (int i = startCount; i < endCount; i++) {
            String repushPath = PRE_PATH + "split_" + (i + 1) + ".xlsx";
            repush(restTemplate, repushPath);
            countDownLatch.countDown();
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }


    public void repush(RestTemplate restTemplate, String path) {

        boolean isSuccess = Boolean.TRUE;

        try {

            List<QfTest.DataModel> dataModelList = ExcelReader.readExcelToList(path);

            BatchHandleUtil.batchHandle(dataModelList, 500, subList -> {

                Set<String> finalSet = subList.stream().map(item -> StringUtils.trim(item.getValue())).filter(StringUtils::isNotBlank).collect(Collectors.toSet());

                log.info("{}-原始个数:{}-去重后个数:{}", path, subList.size(), finalSet.size());

                repushWithPool(restTemplate, finalSet);

            });

        } catch (Exception e) {

            log.error("失败路径-{}", path, e);

            isSuccess = Boolean.FALSE;

        } finally {

            log.info("[repush]执行:{}-{}", path, isSuccess);

        }

    }



    public void repushWithPool(RestTemplate restTemplate, Set<String> finalSet) {

        //CountDownLatch countDownLatch = new CountDownLatch(finalSet.size());

        for (String lpCode : finalSet) {

            threadPoolExecutor.execute(() -> {

                boolean isSuccess = Boolean.TRUE;

                try {

                    ParcelActivity parcelActivity = buildParcelActivity(lpCode);

                    String str = JSONUtil.toJsonStr(parcelActivity);

                    //log.info("{}-生成的请求报文:{}", lpCode, str);

                    doRepushSingle(restTemplate, lpCode, str);

                } catch (Exception e) {

                    log.error("单号:{},请求失败", lpCode, e);
                    isSuccess = Boolean.FALSE;
                    try {
                        fw.write(lpCode+"\n");
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }


                }finally {

                    //countDownLatch.countDown();

                    log.info("[repushWithPool][lpCode]单号{},执行结果:{}", lpCode, isSuccess);

                }

            });

        }

        //try {
        //
        //    countDownLatch.await();
        //
        //} catch (InterruptedException e) {
        //
        //    throw new RuntimeException(e);
        //
        //}

    }











    private void doRepushSingle(RestTemplate restTemplate, String lpCode, String str) {

        // 设置请求头部

        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);

        // 设置Cookie值

        headers.set("Cookie", getCookie());

        // 构建请求实体

        HttpEntity<String> requestEntity = new HttpEntity<>(str, headers);



        // 发送 POST 请求

        ResponseEntity<String> response = restTemplate.exchange(

                "https://os.gpn.cainiao-inc.com/packagenetwork-default-workspace/GLOBAL-PACKAGE-NEWWORK/reActivity/doResend",

                HttpMethod.POST,

                requestEntity,

                String.class

        );

        //log.info("单号:{},请求参数{}, 请求返回{}", lpCode, str, JSONUtil.toJsonStr(response));

        if (HttpStatus.OK.equals(response.getStatusCode())) {

            ResponseData responseData = JSONUtil.toBean(response.getBody(), ResponseData.class);
            if (!responseData.isSuccess() && !responseData.getErrorMsg().endsWith("非GSDP平台订单")) {
                throw new RuntimeException(response.getBody());
            }

        } else {

            throw new RuntimeException(response.getBody());

        }

    }



    private ParcelActivity buildParcelActivity(String lpCode) {

        ParcelActivity parcelActivity = new ParcelActivity();

        ParcelActivity.Params params = new ParcelActivity.Params();

        params.setActivityType("parcel");

        params.setSelectType("LP_CODE");

        params.setNodeCode("SORTING_CENTER");

        params.setActivityCode("SORTING_CENTER_ORDER_INFO_NOTIFY");

        params.setNeedUpdateState(false);

        params.setResourceCode("Tran_Store_13452544");

        params.setNeedPreActivityCheck(false);

        params.setPreActivityType("parcel");

        params.setCroBorSecStage(false);

        params.setOrderType(0);

        params.setMainCode(lpCode);

        parcelActivity.setParams(params);

        parcelActivity.setTenantCode("AE_GLOBAL@CAINIAO_GLOBAL");

        return parcelActivity;

    }



    private String getCookie() {

        return "cna=roVQGV/Qdl0CAWoLHwoYYz+2; JSESSIONID=19666O91-PGD4DRYSDFAGT4775ZY92-C06Z119L-GO1; _temp0=qv8hXYdp6vB17n7aeFg8gdSormjwnAYuMCzrcAUdRTan0u3%2FmOTBQyUtv4bsIy6kvOLukL0lJQU%2BircSVp68hB4LVV4euwTJCDDngmXEO1%2Fc2l3k1vyj6KNGFBpNMfuY9lKwwwq2V43jAW2wYwPVbV9PK82QIWNYNiMvl5RGtFa9v6nVhiAZmxsIzSIq%2BwYQ; cn_account_lang=zh; SSO_LANG_V2=ZH-CN; SSO_EMPID_HASH_V2=4d28a19fc5c287ee9142b00593562a93; SSO_BU_HASH_V2=1e387a787818f77b803a555735045ffa; XSRF-TOKEN=912cb548-580b-420c-aee1-d19f6dea5067; OsInnerPcSessionModel=6D03BA1F1670D5C10B9F4B0C3AD272F0D77417BE0240E9908E847B3C4D7111390F93A8050AA5EEE0CEB8BACFC75EF0CA02EF8EC950E6FA60C7F92DD27E305E8CF20FDB51DE2D2552FF386F53F60E57FDC82CAD39D3CB755BB3DE5232114F23556F0F9BD014539C4254AB0F39985ECED8469D500DA8CEBDA5F1800360CE67509A; _tenant=CAINIAO; cn-groot_USER_COOKIE=F00550F2B365C3609FA99B5E84571874F5B49DC89DD2B0429BEDEE6AE2CEEC77CB6391EBAD79522FFF8D16CE0E4C001115786F597A3F328A4EF91CEF40D4CE5C178B6C51D65BAE460595878464E2DD4A0A136DF4BB5E24A4D6A3C4E3591E78C9994FCE374645FE361BC4CDEF9E86461CD8E1339D11C797F91F7EB6E84630E84BB5E04B53335E3A5733F3CA9778FFC4B645585468BC37FDBBF3DD519D8CE282CECE9E2E757EC1E832D2A6CFB883531EE9CED85A332F406BC80363CC0849490FED17B4F5C2CF5E4671EED8CC68736725770E99D33A2D146F4997DCFAC8851A3DD3510701D5A329E3E774AD2C0EE7A656EC0B50A449E16884962D8060BA0592236C724354B698B5B904B6692F7E856C3E107D7360001C6EA3571A4DBFFAAA8108D6E5EFC68A566749C3604AB2BF288CE52C0A136DF4BB5E24A4D6A3C4E3591E78C9FECDD0E08A0D0AA87ED50239C33FE616C68E636E923B898260B2196B1EB716EA; appCode=7f9cc3273c734100ad51bdc3169a6fea; token=0d26f87a7ce241c3a5ce7b44236f0e000a984100; UUID=886aa3312962494a9b4f533ec5f95e24; xlly_s=1; tfstk=cUrPBJxaZDVX_dUkbmnU_1SyUldRZuGIiIlKrsYodEuHGb3limAKnd3rucp2t4f..; cn-groot_SSO_TOKEN_V2=EC0E5081EB1F75A31F6B8C379FA495B782DDDFE384B58F79363609FE782335022493DADFEFB120FCA870A32177BD76F06D3261B688DB61A6D3704C438F29DECF; isg=BHd3Hhgf380zHl2g8Ubtz_mUBm3BPEuemowfdMkj2cateJW61wt97dUZWtgmkCMW; lang=zh-CN; x-hng=lang=zh-CN; gcep.mcms.language=zh-CN";
    }
}
